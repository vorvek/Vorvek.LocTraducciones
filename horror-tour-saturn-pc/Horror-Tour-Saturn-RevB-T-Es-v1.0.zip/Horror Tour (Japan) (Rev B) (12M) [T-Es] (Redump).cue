FILE "Horror Tour (Japan) (Rev B) (12M) [T-Es] (Track 1).bin" BINARY
  TRACK 01 MODE1/2352
    INDEX 01 00:00:00
FILE "Horror Tour (Japan) (Rev B) (12M) (Track 2).bin" BINARY
  TRACK 02 AUDIO
    INDEX 00 00:00:00
    INDEX 01 00:02:00
